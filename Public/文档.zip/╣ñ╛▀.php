

<?php
	http://office.kingnet.com/
	zhangxj1 qwe!@# 
	
	http://data.mutantbox.com/realtime/adv.html?id=83&levelType=6d09edd292cda822caac1ec8b9970a1b&system=a7493d16fffbdc15b0bdf17b40ee099e
	datauser datauser123
	huoxq huoxq123
	yanz yanz123
	
	内网打开获取pac地址
	http://10.0.0.13/soft/chrome%E7%BF%BB%E5%A2%99/
	http://10.0.0.13/soft/chrome%e7%bf%bb%e5%a2%99/OmegaOptions_res.bak
	
	//echo 后继续执行需开启 fastcgi_finish_request();//继续执行后面的代码
	
	FROM_UNIXTIME(,'%Y-%m-%d') //mysql转时间
	
	phpstorm //激活地址：http://jetbrains.tencent.click
	pycharm //激活地址 http://idea.lanyus.com
	
-- 添加新应用操作：
-- 添加设置栏目、测试栏目、添加页面
-- priv_id是应用权限key（公用）、level_type是终端权限key（公用）、priv是栏目或者页面权限key（私有）
-- 权限查看地址：http://data.mutantbox.com/index/index?checkper=1
	http://data.haymaker.com.cn/index/index?checkper=1
-- id：1 == 设置栏目、2 == 添加页面、3 == 测试栏目（可由添加页面添加）

INSERT INTO menu_list 
(`name`,`show`,`date`,`url`,`class`,`priv`,`priv_id`,`cfg`,`fid`,`asc`,`st`,`et`,`level_type`,`is_display_real`,`is_display_ff`,`time_type`,
`is_display_game`,`is_show`,`dropdownInfo`,`installTimeInfo`,`timestamp`,`type`,`userid`,`creatime`,`static`,`textInfo`,`primary_cfg`) 
SELECT `name`,`show`,`date`,`url`,`class`,`priv`,'d3f7f36094678dd8021aa438e86e2a22',`cfg`,`fid`,`asc`,`st`,`et`,'d3f7f36094678dd8021aa438e86e2a22',
`is_display_real`,`is_display_ff`,`time_type`,`is_display_game`,`is_show`,`dropdownInfo`,`installTimeInfo`,`timestamp`,`type`,`userid`,`creatime`,`static`,
`textInfo`,`primary_cfg` FROM menu_list where id in (1,2,3);

-- 查询初始化id
select * from menu_list order by id desc limit 3 \G;

-- priv是栏目或者页面权限key 、fid是栏目id（id需要执行完上面的操作之后查询）
update menu_list set priv='9e68108ddab59740f7a3dd9bf944b42e' where id =151;
update menu_list set priv='4e2808014808b52456327fed26f9dcdc',fid=151 where id =152;
update menu_list set priv='20af0256610da4364d28e6c2d1b79085' where id =153;

	//获取post数据
	$ps = file_get_contents("php://input");

	//查看内存消耗
	var_dump("内存消耗：",round(memory_get_usage()/1024/1024, 2).'MB');

	//设置时区
	date_default_timezone_set ( 'Asia/Shanghai' );
	
	//打印sql
	DB::listen(function($sql) { dump($sql); });
	\Log::error('sdk YiHuan not  md5Str');
	
	//设置内存大小
	ini_set('memory_limit', '128M')	;
	
	//对象转数组
	get_object_vars();
	
    /**
     * 根据一维数组递归转格式
	 * $arr = [['aa'=>111,'bb'=>22,'cc'=>33],['aa'=>11,'bb'=>2,'cc'=>3]];
	 * $ke = ['aa','bb','cc'];
     */
    public function getMkData($arr, $ke, $da = null)
    {

        $data = [];
        $sky = is_array($ke)?array_shift($ke):$ke;
        foreach ($arr as $vl) {

            if (count($ke) && is_array($ke)) {

                if (!isset($data[$vl[$sky]])) {
                    $data[$vl[$sky]] = [];
                }
                $data[$vl[$sky]] += self::catMoreArr($vl, $ke, $da);
            } else {

                $data[$vl[$sky]] = $da ? $vl [$da] : $vl;
            }
        }
        return $data;
    }

    /**
     * 创建多维数组
     * @param $arr
     * @param $ke
     * @param null $da
     * @return mixed
     */
    public function catMoreArr($arr, $ke, $da = null)
    {

        if (count($ke)>1){
            $last = null;
            while($last = array_pop($ke)) {
                if (!is_array($last)){
                    $last = $da ? $arr [$da] : $arr;
                }
                if(null != $last) {
                    $pop = $arr[array_pop($ke)];
                    array_push($ke,[$pop=>$last]);
                }
                if(count($ke) <= 1) {
                    break;
                }
            }
        }else{

            $last = $da ? $arr [$da] : $arr;
            return [$arr[array_shift($ke)]=>$last];
        }

        return $ke[0];
    }
	
	/**
	 * 数据分类
	 * */
	public function getv($arr,$ks,$vk=""){
		$pc = isset($arr['pc'][$ks])?$arr['pc'][$ks]:"--";
		$mb = isset($arr['mobile'][$ks])?$arr['mobile'][$ks]:"--";
		if ($vk == ""){
			return $pc+$mb;
		}elseif ($vk == 1){
			$data['pc'] = $pc;
			$data['mb'] = $mb;
			return $data;
		}
		else{
			return "(".$this->dataFormat($pc)."/".$this->dataFormat($mb).")";
		}
	}
	
	/**
	 * 星期几
	 * */
	public function getWeek($tims = ""){
		$res = array('周日','周一','周二','周三','周四','周五','周六');
		return ($tims)?$res[date("w",strtotime($tims))]:$res;
	}

	/**
	 * 千分位
	 * */
	public function getFormat($num){
		return ($num=='--')?'--':number_format($num);
	}
	
	/**
	 * 删除千分位
	 * */
	public function del_format($arr){
		$data="";
		if (is_array($arr)){
			foreach ($arr as $key => $value){
				$data[$key] = str_replace(",","",$value);
			}
		}else{
			$data = str_replace(",","",$arr);
		}
		return $data;		
	}	
		
	/**
	 * 递归合并数组
	 * 二维数组重新组合
	 * */
	public function mer_array($arr){
		$data = array();
		foreach ($arr as $k => $v){
			$v = $this->del_format($v);
			$data = array_merge_recursive($data,$v);
		}
		return $data;
	}
	
	
	/**
	 * 千分位
	 * */
	public function getFormat($num){
		if (is_array($num)){
			foreach ($num as $k=>$v){
				$arr = explode(".", $v);
				$ent = (isset($arr[1])&&strlen($arr[1])>0)?".".$arr[1]:"";
				$num[$k] = ($v=='--')?'--':number_format($arr[0]).$ent;
			}	
		}else{
			$arr = explode(".", $num);
			$lens = isset($arr[1])?strlen($arr[1]):0;
			$num = ($num=='--')?'--':number_format($num,$lens);
		}
		
		return $num;
	}

	/**
	 * 创建时间数组
	 * */
	private function DateArray($s,$e){
		$_time = range(strtotime($s), strtotime($e), 24*60*60);		
		return array_map(create_function('$v', 'return date("Y-m-d", $v);'), $_time);		
	}

	/**
	 * 判断除数
	 * */
	public function getDivision($A, $B){
		return empty($B) ? '0' : round(($A*100/$B),2);
	}
	
	public function getRete($A, $B){
        return $B ? $A * 100 / $B : 0;
    }
	
	public function getDivision($A, $B,$c=100,$d=''){
		return empty($B) ? '0'.$d : round(($A*$c/$B),2).$d;
	}
	
	/**
     * 判断目录是否存在，不存在则创建
     * @param unknown $path
     */
    function mkFolder($path)
    {
    	if(!is_readable($path))
    	{
    		is_file($path) or mkdir($path,0700);
    	}
    }
	
    /**
     * 递归保留指定小数位
     * */
    private function _decimals($arr = [], $lens = 2){
    	
    	if (is_array($arr) && count($arr) > 0){
    		foreach ($arr as $key => $value){
    			$arr[$key] = $this->_decimals($value,$lens);
    		}
			return $arr;    		
    	}else{
    		if(ceil($arr)!=$arr){
    			$num = explode(".", $arr);
				if(isset($arr[1]) && count($num) == 2){
					return ($arr=='--')?'--':number_format($arr,$lens);
				}else{
					return $arr;
				}    			
    		}else{
    			return $arr;
    		}
    	}
    	
    }
	
	/**
	 * 获取数据
	 */
	public function getData($request,$type=''){
		if(isset($request['sql']) && isset($request['db'])){
			if (isset($_GET['debug'])){
				$this->getDebug($request['sql'],$type);
				return array();
			}
			if ($request['tp']=='row'){
				$data = Yii::app()->$request['db']->createCommand($request['sql'])->queryRow();
			}else{
				$data = Yii::app()->$request['db']->createCommand($request['sql'])->queryAll();
			}	
			return $data;
		}
		return array();
	}	
	
	/**
	 * 取数
	 * */
	public function getData($sql,$type,$tm=false){
		if (isset($_GET['debug'])){
			$this->getDebug($sql,$type);
			return array();
		}
		$row  =  $this->db->query($sql)->result_array();
		return ($tm)?$this->getmk($row,$tm):$row;
	}

	/**
	 * 转格式
	 * */
	public function getMk($arr,$ke){
		$data=array();
		if (is_array($arr)&&count($arr)>0){
			foreach ($arr as $k=>$v){
				$data[$v[$ke]]=$v;
			}
		}
		return $data;
	}

	/**
	 * 转格式2
	 * */
	public function getMks($arr,$ke,$kes){
		$data=array();
		if (is_array($arr)&&count($arr)>0){
			foreach ($arr as $k=>$v){
				$data[$v[$ke]][$v[$kes]]=$v;
			}
		}
		return $data;
	}
	
	/**
	 * 转格式
	 * */
	public function getMk2($arr,$ke){
		$data=array();
		if (is_array($arr)&&count($arr)>0){
			foreach ($arr as $k=>$v){
				$data[$v[$ke]]=$v[$ke];
			}
		}
		return $data;
	}
	
	/**
     * 校验日期格式是否正确
     * @param string $date 日期
     * @param string $formats 需要检验的格式数组
     * @return boolean
     */
    function checkDateIsValid($date, $formats = array("Y-m-d", "Y/m/d")) {
        $unixTime = strtotime($date);
        if (!$unixTime) { //strtotime转换不对，日期格式显然不对。
            return false;
        }

        //校验日期的有效性，只要满足其中一个格式就OK
        foreach ($formats as $format) {
            if (date($format, $unixTime) == $date) {
                return true;
            }
        }
        return false;
    }

	/**
	 * 组合where
	 * */
	public function Comarr($arr){
		$str = "";
		foreach ($arr as $k => $v){
			$str .=" and ".$k." '".$v."'";
		}
		return $str;
	}
	
	/**
	 * 批量替换
	 * $key = array();$value=array();
	 * str_ireplace($key,$value,$str);
	 * */
	public function getStrple($str,$arr=array()){
		if (count($arr)>0){
			foreach ($arr as $key => $value){
				$str = str_ireplace($key,$value,$str);
			}
		}
		return $str;
	}
	
	/**
	 * 去除最后的下标命名
	 * */
	private function getQueryData($arr=[]){
		if (count($arr)>0){
			foreach ($arr as $k=>$v){
				if (is_array($v)){
					$arr[$k] = array_values($v);
				}else{
					$arr[$k] = $v;	
				}			
			}		
		}
		return $arr;
	}

	/**
	 * debug输出
	 */
	public function getDebug($sql='',$type=''){
		$uidArr = array('zhangy');
		if (isset($_GET['debug'])){
			var_dump($type.":".$sql."\r\n<br/>");
		}
	}
	
	/**
     * 导出
     * */
    public function exl($title, $res , $fle){
    	$download = isset($_POST['download']) ? (int)($_POST['download']) : 0 ;		
		if($download){$this->_export($title, $res, $fle);exit;}
    }
	
	/**
     * 导出功能,导出格式为CSV,按照标准格式导出  浏览器输出
     */
    public function _export($title,$data,$fname) {
        $fname = $fname?$fname:time();
        header("Content-Type: application/vnd.ms-execl;charset=gbk");
        header("Content-Disposition: attachment; filename=".urlencode($fname).".xls");
        header("Pragma: no-cache");
        header("Expires: 0");
        //组合标题
        $str = implode("\t",$title)."\t\n";
        //组合data
        foreach ($data as $key=>$value){
            $str .= implode("\t",$value)."\t\n";
        }
        echo iconv("UTF-8","GBK//IGNORE",$str);
    }
	
	/**
	 * 判断二维数组
	 */
	public function Kiwi($arr){
		if(is_array(current($arr))){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 二维数组排序
	 */
	public function array_sort($arr, $keys, $type='asc', $is_key=TRUE){
		$keysvalue = $new_array = array();
		foreach ($arr as $k=>$v){
			if(isset($v[$keys])){
				$keysvalue[$k] = (int)$v[$keys];
			}else{
				return $arr;//$keysvalue[$k] = $v;
				break;
			}
		}
		if(strtolower($type) == 'asc'){
			asort($keysvalue);
		}else{
			arsort($keysvalue);
		}
		reset($keysvalue);
		foreach ($keysvalue as $k=>$v){
			if($is_key){
				$new_array[] = $arr[$k];
			}else{
				$new_array[$k] = $arr[$k];
			}
		}
		return $new_array;
	}
	
	//对二维数组进行自定义排序
	function myusort($array,$field,$order='desc')
	{	
		if(!is_array($array) || !$array) return array();
		$sort_array = array();
		foreach($array as $k=>$v)
		{	
			if(!isset($v[$field]))
				$sort_array[] = '';
			else
				$sort_array[] = $v[$field];
		}

		if($order === 'desc')
		{
			array_multisort($sort_array,SORT_DESC,$array);
		}
		else
		{
			array_multisort($sort_array,SORT_ASC,$array);
		}
		return $array;
	}
	
	 /**
     * 记录错误
     * @param $c
     * @param string $f
     */
	public function setFileerror($c,$f=""){
        $f = empty($f)?dirname(__DIR__)."/log/ini_error_".date("Y-m-d",time()).".log":$f;
        file_put_contents($f,date("Y-m-d H:i:s",time()).$c.PHP_EOL,FILE_APPEND);
    }

    /**
     * set(key,value);  设置无过期缓存
     * get(key);    获取缓存
     * setex(key,time,value);   设置带有过期缓存
     * ttl(key);    获取过期时间
     * @param string $ips
     * @param string $pros
     * @return \Redis
     */
    public function redis($ips='',$pros=''){

        $ips = empty($ips)?'172.31.5.232':$ips;
        $pros = empty($pros)?'6380':$pros;
        $redis = new  \Redis();
        $redis->connect($ips,$pros);
        return $redis;
    }
	
	
    /**
     * 判断目录是否存在，不存在则创建
     * @param unknown $path
     */
    public function mkFolder($path)
    {
    	if(!is_readable($path))
    	{
    		is_file($path) or mkdir($path,0700,true);
    	}
    }
	
	//动态计算
	public function dtjs(){
		
		$a=111;
        $b='/';
        $c='100';
        echo eval("return {$a}{$b}{$c};");
	}
	
	
	/**
     * 自动加载类
     */
    private function loaders(){
        spl_autoload_register(function ($className) {
            $file = HER_DIR.str_replace('\\', '/', $className). '.class.php';
            //var_dump($file,file_exists($file));exit;

            if( file_exists($file) ){
                include $file;
            }
        });
    }	
	
	/**
	 * 插入结果集数据表
	 * $t 表名
	 * $d 数据
	 * $logdir 日志路径
	 */
	private function Insert($t, $d,$logdir) {
		$isql = "INSERT INTO $t(`fds`,`server_id`, `login_num`, `reg_num`, `gen_angle_num`, `new_reg`, `new_gen_angle`, `gen_angle_rate`, `income`, `arppu`) VALUES ";
		
		if (count ( $d )) {
			// exit;
			$isql .= implode ( ',', $d );
		
			$isql .= " ON DUPLICATE KEY UPDATE login_num=VALUES(login_num), reg_num=VALUES(reg_num), gen_angle_num=VALUES(gen_angle_num), new_reg=VALUES(new_reg),
						new_gen_angle=VALUES(new_gen_angle), gen_angle_rate=VALUES(gen_angle_rate), income=VALUES(income), arppu=VALUES(arppu)";
		
			var_dump ( $isql );exit;
			//file_put_contents ( "./log/d_advert_days_" . date ( "Y-m-d", time () ) . "_sql_error.log", $isql );exit;
			try {
				file_put_contents ( $logdir . "d_server_" . date ( "Y-m-d", time () ) . "_sql.log", $isql );
				$this->_db_conn->exec ( $isql );
			} catch ( Exception $e ) {
				$e->getMessage ();
				file_put_contents ( $logdir . "d_server_" . date ( "Y-m-d", time () ) . "_sql_error.log", $isql );
			}
		}
	}
	
    /**
	 * 查询数据
	 * 
	 * @param db对象 $dbcenter        	
	 * @param 库名.表名 $tbl        	
	 * @param 查询条件 $whe        	
	 * @param 查询字段 $query_field        	
	 * @param string $group_field        	
	 * @param string $not_arr        	
	 * @return multitype:unknown |multitype:
	 */
	public function query_data($dbcenter, $tbl, $whe, $query_field, $group_field = '', $not_arr = false) {
		$rows = [ ];
		$sql = "SELECT $query_field FROM $tbl where 1 $whe";
		if (isset ( $_REQUEST ['debug'] ) && $_REQUEST ['debug'] == 1) {
			var_dump ( $dbcenter, $sql );
			return $rows;
		}
		
		if ($this->iscatTables ( $dbcenter, $tbl )) {
			$rows = $dbcenter->getAll ( $sql );
			if ($group_field) {
				return ($not_arr) ? $this->getMk ( $rows, $group_field, $group_field ) : $this->getMk ( $rows, $group_field );
			}
		}
		return $rows;
	}
	
	/**
	 * 判断表是否存在，不存在则按规则创建
	 * 
	 * @param DB对象 $db        	
	 * @param 表名 $tableName        	
	 * @param string $dbName        	
	 * @param string $rules  日期格式      	
	 * @return string 
	 * 			iscatTables($db,库.表) 适合同库，规则相同表之间的表镜像
	 * 			iscatTables($db,表,库,规则) 适合同库，规则相同表之间的表镜像
	 *         iscatTables($db,库.表,库1,规则) 适合不同库，规则相同表之间的表镜像
	 *         iscatTables($db,库.表,'','',库1.表) 适合不同库，之间的表镜像
	 *         不支持跨服务器创建
	 */
	public function iscatTables($db, $tableName, $dbName = '', $rules = 'Y_m', $mrtable = '') {
		
		$str = true;//"$tableName表已存在";
		if ($mrtable) {
			$str = true;
			try {
				$db->exec ( "CREATE TABLE $tableName  LIKE $mrtable" );
				$str = true;//"已创建表：$tableName结构来源表：$mrtable";
			}catch (PDOException $e){
				$e->getMessage();
				$str = false;
			}
			return $str ;
		}
		
		//规则查询
		if (! $this->ifTable ( $db, $tableName, $dbName )) {
			
			$tablens = $tableName;
			$st = time ();
			$et = strtotime ( "-1 years" );
			for(; $st >= $et;) {
				
				$sts = strtotime ( date ( 'Y-m-d',$st ) . "-1 month" );
				$tablens = str_ireplace ( date ( $rules, $st ), date ( $rules, $sts ), $tablens );
				if ($this->ifTable ( $db, $tablens, $dbName )) {
					
					try {
						if ($dbName) {
							$db->query ( "use $dbName" );
						}
						$db->exec ( "CREATE TABLE $tableName  LIKE $tablens" );
						$str = true;//"已创建表：$tableName结构来源表：$tablens";
					}catch (PDOException $e){
						$e->getMessage();
						$str = false;
					}				
					break;
				} else {
					$str = false;//"$tableName表创建失败";
				}
				$st = $sts;
			}
		}
		
		return $str;
	}
	
	/**
	 * 判断库是否存在，不存在则创建
	 * 
	 * @param DB对象 $db        	
	 * @param string $dbName        	
	 * @return string
	 */
	public function iscatDatabases($db, $dbName) {
		
		$str = true;//"$dbName库已创建";
		$database = $db->getAll ("SHOW DATABASES");
		if (is_array($database) && count($database)){
			$database = array_values ( $this->mer_array ($database))[0];
		}else{
			return false;
		}
		
		try {
			if (is_array($database)){
				if (!in_array($dbName, $database)){
					$db->exec ( "CREATE DATABASE IF NOT EXISTS $dbName DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci" );
					$str = true;
				}
			}else {
				if ($dbName!=$database){
					$db->exec ( "CREATE DATABASE IF NOT EXISTS $dbName DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci" );
					$str = true;
				}
			}
		}catch (PDOException $e){
			$e->getMessage();
			$str = false;
		}
			
		return $str;
	}
	
	/**
	 * 检查表是否存在
	 * 
	 * @param db对象 $db        	
	 * @param 表名 $tableName        	
	 * @param 数据库名 $dbName        	
	 * @return boolean 
	 * 			ifTable($db,表) 按默认配置查询表是否存在
	 *         ifTable($db,表,库) 按给定库查询表是否存在
	 *         ifTable($db,库.表) 按给定库查询表是否存在
	 *         不支持跨服务器查询
	 */
	public function ifTable($db, $tableName, $dbName = '') {
		
		$exp = explode ( '.', $tableName );		
		try {
			if (count ( $exp ) == 1) {
				if ($dbName) {
					
					$tr = $this->iscatDatabases($db,$dbName);
					if ($tr){
						$sql = "SHOW TABLES FROM " . $dbName;
						$tables = $db->getAll ( $sql );
					}else {
						return false;
					}
				} else {
					$tables = $db->getAll ( 'show tables' );
				}
			} else {
					
				$tr = $this->iscatDatabases($db,$exp [0]);
				if ($tr){
					$sql = "SHOW TABLES FROM " . $exp [0];
					$tables = $db->getAll ( $sql );
					$tableName = $exp [1];
				}else {
					return false;
				}
			}
		}catch (PDOException $e){
			$e->getMessage();
			return false;
		}
		
		if (is_array($tables) && count($tables)){
			$tables = array_values ( $this->mer_array ( $tables ) )[0];
		}else {
			return false;	
		}
		
		$bl = false;		
		if (is_array($tables)){
			if (in_array ( $tableName, $tables )) {
				$bl = true;
			}
		}else{
			if ($tables == $tableName){
				$bl = true;
			}
		}
		return $bl;
	}
	
	/**
	 * 检查表是否存在
	 * */
	public function listTable($tableName,$db,$tbl){
		
		$indb=$this->indb;
		$sql="SHOW TABLES FROM ".$tbl;
		$tables = Yii::app()->$indb[$db]->createCommand($sql)->queryAll();	
		$tables = $this->mer_array($tables);
		if(in_array($tableName, $tables['Tables_in_'.$tbl])){
			return true;
		}
		return false;			
	}
	
	/**
	 * 检查表是否存在
	 * */
	function list_tables($tableName){
		$rs = mysql_query("SHOW TABLES FROM realtime_app");			
		$tables = array();
			
		while ($row = mysql_fetch_row($rs)) {
			$tables[] = $row[0];
		}
		mysql_free_result($rs);
		if(in_array($tableName, $tables)){
			return true;
		}
		return false;			
	}
	
	/**
	 * 递归合并数组
	 * 二维数组重新组合
	 * */
	public function mer_array($arr){
		$data = array();
		foreach ($arr as $k => $v){
			$data = array_merge_recursive($data,$v);
		}
		return $data;
	}
	
	/**
	* 查看进程是否启动
	*/
	public function check_pid($file_name,$pid_name){
		
		$tt = [];
		exec("ps aux|grep $file_name | grep -v grep",$tt);
		if(isset($tt[0])&&count($tt[0])){
			$tt = explode(" ",$tt[0]);
			$tt = array_values(array_filter($tt));
			$file_name = $pid_name;
			if (file_exists($file_name)){
				$fnum = file_get_contents($file_name);
				if ($fnum == $tt[0]){
					echo "进程已启动！";exit;
				}else{
					$dd = [];
					exec("ps ax|grep $fnum | grep -v grep",$dd);

					if (isset($dd[0])&&count($dd[0])){
						$dd = explode(" ",$dd[0]);
						$dd = array_values(array_filter($dd));
						if (end($dd) != end($tt)){
							file_put_contents($file_name,$tt[0]);
						}else{
							echo "进程已启动！";exit;
						}
					}else{
						file_put_contents($file_name,$tt[0]);
						//echo "进程id不一样！";exit;
					}
				}
			}else{
				file_put_contents($file_name,$tt[0]);
			}
		}
	}
		
	/**
	 * 运算 $this->getsb([],array_sum);
	 * */
	public function getsb($arr,$h,$b=false){
		$data=array();$data1=array();
		foreach ($arr as $k=>$v){
			$data[$k]=$data1[]=$h($v);
		}
		return ($b)?$data1:$data;
	}
	
	/**
	 * 转换类型 $this->getTpes($data, 'floatval',["channel_name"]);
	 * */
	public function getTpes($arr,$type,$no=[]){
		foreach ($arr as $key => $value){
			foreach ($value as $k => $v){
				$arr[$key][$k]=$v;
				if (!in_array($k, $no)){
					$arr[$key][$k]=$type($v);	
				}
			}
		}
		return $arr;
	}
	/**
	 * 叠加
	 */
	public function getArrSum($arr){
		$sum = 0;
		foreach ($arr as $key => $value){
			if(in_array($key, array_keys($this->channel))){
				$sum += $value;
			}
			
		}
		return $sum;
	}
	
	/*
	 * 获取时间
	 */
	public  function getH(){
		$time = time();
		$i = date('i');
		if( $i <= '55'){
			$h = date('G');
		}else{
			$h = date('G')-1;
		}
		return $h;
	}
	
	/**
     * 取周一和周日
     * */
    public function getWeeks($tms){
        $dts = [];
        $fms = strtotime($tms);
        if ($fms){
            $wmt = date('w', $fms);
            $ki = ($wmt == 0)? '-6':(1 - $wmt);
            $kj = ($wmt == 0)? 0:(7 - $wmt);
            $dts['st']=date("Y-m-d",strtotime("{$tms} $ki day"));
            $dts['et']=date("Y-m-d",strtotime("{$tms} $kj day"));
        }
        return $dts;
    }

    /**
     * 取月第一天和最后一天
     * */
    public function getMoth($tms){
        $dts = [];
        $tms = strtotime($tms);
        if ($tms){
            $dts['st']=date('Y-m-01', $tms);
            $dts['et']= date('Y-m-d', strtotime("{$dts['st']} +1 month -1 day"));
        }
        return $dts;
    }
	
	/**
	 * 取周一和周日
	 * */
	public function getWeek_s(){
		$dts = array($this->date_s);
		$i=strtotime($this->date_s);
		$j=time();
		for(;$i<=$j;$i+=604800){
			$dts[]=date("Y-m-d",strtotime("Sunday",$i));
			$dts[]=date("Y-m-d",strtotime("Monday",$i));
		}
		array_pop($dts);
		$dts = array_filter($dts);
		return $dts;
	}
	
	/**
	 * 取周几日期
	 * */
	public function getWeek($wek,$dts = array()){
		$i=strtotime($this->date_s);
		$j=time();
		for(;$i<=$j;$i+=604800){
			$dts[] = date("Y-m-d",strtotime($wek,$i));
		}
		$dts = array_filter($dts);
		return $dts;
	}

	/**
	 * 取月一天
	 * */
	public function getMoth($dst='Y-m-01',$dts = array()){
		$i=strtotime($this->date_s);
		$j=time();
		for(;$i<=$j;){
			$dts[] = date($dst, $i);
			$i=strtotime(date("Y-m-d",$i)."+1 month");
		}
		$dts = array_filter($dts);
		return $dts;
	}
	
	/**
     * 计算差天
     * @param $zero1
     * @param $zero2
     * @return bool|float
     */
    public function getDayNum($zero1,$zero2){

        if (!empty($zero1) && !empty($zero2)){
            return ceil(($zero2-$zero1)/86400);
        }else{
            return false;
        }
    }

    /**
     * 计算差月
     * @param $date1
     * @param $date2
     * @return bool|number
     */
    function getMonthNum($date1,$date2){

        if (!empty($date1) && !empty($date2)){
            $date1_stamp=strtotime($date1);
            $date2_stamp=strtotime($date2);
            list($date_1['y'],$date_1['m'])=explode("-",date('Y-m',$date1_stamp));
            list($date_2['y'],$date_2['m'])=explode("-",date('Y-m',$date2_stamp));
            return abs($date_1['y']-$date_2['y'])*12 +$date_2['m']-$date_1['m'];
        }else{
            return false;
        }
    }
	
	/**
	 * 日志文件操作
	 * */
	public function fops($fps,$fname){
		$path = dirname(Yii::app()->basepath).'/log';
		if(!file_exists($path)){
			mkdir($path,0777);
		}
		$fp = fopen($path."/Rundata-".$fname.date('Y-m-d')."txt", "a");
		fwrite($fp,$fps);
		fclose($fp);
	}
	
	/**
	 * 文件操作
	 * */
	public function Fops($fps,$fname,$path){
		
		if(!file_exists($path)){
			mkdir($path,0777);
		}
		$res = "写入 $fname 成功";
		$fp = fopen($path."/".$fname, "w");
		if(fwrite($fp,$fps) == false){
			$res = "写入 $fname 失败";
		}
		fclose($fp);
		return $res;
	}
	
	/**
	 * 数据处理
	 * */
	public function data_handle($att=array()){
		if (count($att)>0){
			$dataset=array('%20','%27','%2527','*',"'",'"',';','{','}','\\','<','>');
			$reset=array();
			foreach ($att as $key=>$val){
				$reset[$key]=str_ireplace($dataset,"",$val);
			}
			return $reset;
		}else {
			echo "数据不能为空-->时间：".date('Y-m-d H:i:s').PHP_EOL;
		}
	}
	
	/**
     * 处理提交数据
     * @param $part
     * @return mixed
     */
	public function handle($part) {

	    if(count($part) && is_array($part)){
            foreach ($part as $k => $value){
                $part[$k] = $this->handle($value);
            }
            return $part;
	    }else{
           return preg_replace('/[^\w\.]/','',$part);
        }
	}

	/**
	 * 按参数调用方法
	 * 返回格式为数组
	 */
	public function getDataFromModule($param, $type) {
		$getMethod = 'get'.ucfirst($type);
		if(method_exists($this->md, $getMethod)) {
			$retArr = $this->md->$getMethod($param);
		} else {echo $getMethod;die;
			//$this->debug->set(get_class($this->md).'的方法'.$getMethod.'不存在!');
			$retArr = array();
		}
		return $retArr;
	}
	
	/*
    *格式数字表示的星期中的第几天
    */
    public function getWeekOneDay($date){
        $day = date('N',strtotime($date));
        switch ($day) {
            case '1':
                return '一';
                break;
            case '2':
                return '二';
                break;
            case '3':
                return '三';
                break;
            case '4':
                return '四';
                break;
            case '5':
                return '五';
                break;
            case '6':
                return '六';
                break;
            case '7':
                return '日';
                break;
        }
    }
	
	/**
	 * 取数据
	 */
	public function getData($sql) {
		$res = mysql_query($sql, $this->_link);
		$retArr = array();
		while($row = mysql_fetch_assoc($res)) {
			$retArr[] = $row;
		}
		return $retArr;
	}
	
	/**
	 * 取单条
	 */
	public function getDataRow($sql) {
		$res = mysql_query($sql, $this->_link);
		$retArr = array();
		if($res){
			$retArr = mysql_fetch_assoc($res);
		}else{
			echo '|error:'.$sql.'='.mysql_error();
		}
		return $retArr;
	}
		
	/**
	 * case when
	 * $this->casewhend($tms,'sum(','`id_count`','fds');
	 * 多条更新
	 * update t_user_00 set 
		f_subref = case 
		when f_ouid= 900 and f_iuid=23406028064058 and f_serverid=1 then 'fb-aaa-cc-dad' 
		when f_ouid='8801sf' and f_iuid=23405004744058 and f_serverid=1 then 'gg-asda-cfs-dad' 
		end,
		f_mainref = case 
		when f_ouid= 900 and f_iuid=23406028064058 and f_serverid=1 then 'web' 
		when f_ouid='8801sf' and f_iuid=23405004744058 and f_serverid=1 then 'ios' 
		end,
		WHERE id IN (900,8801sf);
	 * */
	public function casewhend($arr,$juhe,$module,$name,$nday=0){
		$case="";
		foreach ($arr as $ks =>$val){
			if ($vke = &$arr[($ks+1)]){
				$case .= "{$juhe}case when {$name} > '{$val}' and {$name} <= '{$vke}' then {$module} end ) as '".date("Y-m-d",strtotime("$vke - $nday day"))."',";
			}/*else{
				$case .= "{$juhe}case when {$name} >= '{$val}' then {$module} end ) as '{$val}'";
			}*/
		}
		return substr($case,0,-1);
	}	

    /**
     * 递归处理数据
     * */
    public function getIndata($data,$kid,$inke=''){
    	$data = ($inke && isset($data[$inke]))?$data[$inke]:$data;
    	$kid = ($inke && isset($kid[$inke]))?$kid[$inke]:$kid;
    	if(count($kid)>0 && count($data)>0){
		   	foreach ($data as $key => $value){
		   		if(is_array($value) && is_array($kid[$key])){
			   		$data[$key] = $this->getIndata($value, $kid[$key]);
		   		}else{
		   			if ($key != 'old_rate' && $key != 'statdate'){
		   				$val = isset($kid[$key])?$kid[$key]:0;
		   				$data[$key] = $value+$val;
		   			}
		   		}
		    } 
    	}else{
    		$data = count($data)?$data:$kid;
    	}
    	return $data;	
    }
	
	/**
	 * 删除数组
	 */
	public function unsetarr($res = array() , $delkey = ""){
		if (is_array($delkey) && count($delkey)>0){
			foreach ($delkey as $value){
				foreach ($res as $key => $val){
					unset($val[$value]);
					$res[$key] = $val;
				}					
			}
		}else{
			if ($delkey != ""){
				foreach ($res as $key => $val){
					unset($val[$delkey]);
					$res[$key] = $val;
				}
			}
		}
		return $res;
	} 
	
	/**
	 * 批量添加	》	键为最小值（key），值为最大值（value）
	 * $this->ret=$this->getMdata($this->ret,array(16000=>20000,),100);
	 * */
	private function getMdata($arr,$arr1,$nums=1){
		$data=array();
		foreach ($arr1 as $key => $val){
			for(;$key<=$val;){
				$data[$key] = $key; $key+=$nums;
			}
		}		
		$act = array_merge($arr,$data);
		return array_combine($act,$act);	
	}
		
	/**
	 * 替换日期
	 * */
	public function Repttab($tis,$str){
		
		$arr = array("/\d{4}-\d{2}-\d{2}/i","/\d{4}\/\d{2}\/\d{2}/i","/\d{8}/i");
		foreach ($arr as $val){
			$tis = preg_replace($val,$str,$tis);
		}
		return $tis;
	}
	
	/**
	 * 取库、表
	 * */
	public function actionGet_dbtable($info=''){
		$indb = $this->indb;
		
		$db = isset($_REQUEST['db'])&&$_REQUEST['db']!=""?$_REQUEST['db']:"";
		$tab = isset($_REQUEST['tab'])&&$_REQUEST['tab']!=""?$_REQUEST['tab']:"";
		$sut = isset($_REQUEST['sut'])&&$_REQUEST['sut']!=""?$_REQUEST['sut']:"";
		
		if ($tab && $db){
			if ($sut){
				$sql="SHOW FULL COLUMNS FROM  $tab.`$sut`";
				$data['data'] = Yii::app()->$indb[$db]->createCommand($sql)->queryAll();
				$data['data'] = $this->getMk($data['data'], 'Field','Comment');
				$data['data'] = $data['data'];
			}else{
				$sql="SHOW TABLES FROM ".$tab;
				$data['sut'] = Yii::app()->$indb[$db]->createCommand($sql)->queryAll();
				$data['sut'] = $this->mer_array($data['sut']);
				$data['sut'] = $data['sut']['Tables_in_'.$tab];
			}
		}else{
			if($db && isset($indb[$db])){
				$notin = ['kana_','1117124_','1117136_','_'.date("Y"),'hadoop_','mob_','storm_','user_','xyplat','xyzs','zsgg','annual_report'];
				$sql="SHOW DATABASES";
				$data['tab'] = Yii::app()->$indb[$db]->createCommand($sql)->queryAll();
				$data['tab'] = $this->mer_array($data['tab']);
				$data['tab'] = $this->fitData($data['tab']['Database'],$notin);
			}else {
				$data['db'] = $indb;
			}
		}
		//var_dump($_REQUEST,$db,$data);exit;
		if ($db || $tab || $sut){
			if ($info){
				return $data;
			}else{
				echo json_encode($data);
			}				
		}else{
			return $data;	
		}		
	}
	
	/**
	 * 过滤展示数据
	 * */
	public function fitData($arr = [], $att = []){
		$data = [];
		foreach ($arr as $key => $value){
			foreach ($att as $k => $v){
				if (stripos($value,$v)!==false){
					$data[$key] = $value;
				}				
			}
		}
		return $data;
	}
	
	/**
	 * 删除数组
	 * */
	public function rmArr($data,$arr){
		if (count($arr)>0 && count($data) >0){
			foreach ($arr as $k => $v){
				unset($data[$v]);
			}
		}else{
			if (count($data) >0 && !is_array($arr)){
				unset($data[$arr]);
			}
		}
		return $data;
	}
		
	
	/**
	 * 按分钟返回时间
	 * @param int $num
	 * @return int
	 */
	 function seg_minutes($num = 5,$times = ''){

        $tis = ($times)?date('i',$times):date('i',time());
        $tis = $tis-$tis%$num;
        return ($times)?date("Y-m-d H:$tis:0",$times):date("Y-m-d H:$tis:0",time());
    }
	
	/**
	 * 并发请求
	 * @param $query_arr
	 * @param $pdata
	 * @return array
	 */
	function curl_multi_request ($query_arr,$pdata) {
		$ch = curl_multi_init();
		$count = count($query_arr);
		$ch_arr = $results = array();
		$curl_num = 0;
		$curl_max = 100;

		if(is_array($pdata) && $count){

			foreach ($query_arr as $k=>$v) {
				foreach ($pdata as $ks => $va) {
					$ch_arr[$k][$ks] = curl_init($v);
					//curl_setopt($ch_arr[$k][$ks], CURLOPT_POST, 1);
					curl_setopt($ch_arr[$k][$ks], CURLOPT_POSTFIELDS, $va);
					curl_setopt($ch_arr[$k][$ks], CURLOPT_RETURNTRANSFER, true);
					curl_multi_add_handle($ch, $ch_arr[$k][$ks]);

					if ($curl_num >= $curl_max){
						$curl_num = 0;
						$running = null;
						do {
							curl_multi_exec($ch, $running);
						} while ($running > 0);
					}
					$curl_num++;
				}
			}

			foreach ($query_arr as $k=>$v) {
				foreach ($pdata as $ks => $va) {
					$results[$k][$ks] = curl_multi_getcontent($ch_arr[$k][$ks]);
					curl_multi_remove_handle($ch, $ch_arr[$k][$ks]);
				}
			}
			curl_multi_close($ch);

		}else{

			foreach ($query_arr as $k=>$v) {
				$ch_arr[$k] = curl_init($v);
				curl_setopt($ch_arr[$k], CURLOPT_POSTFIELDS, $pdata);
				curl_setopt($ch_arr[$k], CURLOPT_RETURNTRANSFER, true);
				curl_multi_add_handle($ch, $ch_arr[$k]);

				if ($curl_num >= $curl_max){
					$curl_num = 0;
					$running = null;
					do {
						curl_multi_exec($ch, $running);
					} while ($running > 0);
				}
				$curl_num++;
			}

			foreach ($query_arr as $k=>$v) {
				$results[$k] = curl_multi_getcontent($ch_arr[$k]);
				curl_multi_remove_handle($ch, $ch_arr[$k]);
			}
			curl_multi_close($ch);
		}
		return $results;
	}
	
	/**
	 * POST提交
	 */
	public static function post($url, $post_data = '', $timeout = 5){//curl 
        $ch = curl_init(); 
        curl_setopt ($ch, CURLOPT_URL, $url); 
        curl_setopt ($ch, CURLOPT_POST, 1); 
        if($post_data != ''){ 
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data); 
        } 
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
         curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
        curl_setopt($ch, CURLOPT_HEADER, false); 
        $file_contents = curl_exec($ch); 
        curl_close($ch); 
        return $file_contents; 
    }
 
 
    public static function post2($url, $data){//file_get_content
        $postdata = http_build_query($data);
        $opts = array('http' => 
                      array( 
                          'method'  => 'POST', 
                          'header'  => 'Content-type: application/x-www-form-urlencoded', 
                          'content' => $postdata 
                      ) 
        );
        $context = stream_context_create($opts); 
        $result = file_get_contents($url, false, $context);
        return $result;
    }
 
 
    public static function post3($host,$path,$query,$others=''){//fsocket 
        $post="POST $path HTTP/1.1\r\nHost: $host\r\n"; 
        $post.="Content-type: application/x-www-form-"; 
        $post.="urlencoded\r\n${others}";
         $post.="User-Agent: Mozilla 4.0\r\nContent-length: "; 
        $post.=strlen($query)."\r\nConnection: close\r\n\r\n$query"; 
        $h=fsockopen($host,80); 
        fwrite($h,$post); 
        for($a=0,$r='';!$a;){
                $b=fread($h,8192); 
                $r.=$b; 
                $a=(($b=='')?1:0); 
            } 
        fclose($h); 
        return $r; 
    }
	
	/**
     * 格式化日志
     * @param unknown $fm
     * @param unknown $da
     * @param unknown $file
     * @return multitype:
     */
    public function formatting($fm, $da, $file) {
    	$fmcnt = count ( $fm );
    	$dacnt = count ( $da );
    	if ($fmcnt == $dacnt && $fmcnt && $dacnt) {
    		$da = array_combine ( $fm, $da );
    	} else {
    		file_put_contents ( $this->logdir . $file . "_error.log", implode ( ' \t ', $da ) . "\n", FILE_APPEND );
    	}
    	return $da;
    }
		
	/**
	 * 修改多语言数据库权限
	 * */
	public function getSQL(){ kana => setlang.php
		$mod = ['th'=>'th'];$did=[];
		$param['db'] = 'kana_center';
        $param['type'] = 'array';
        $param['sql'] = 'SELECT * FROM `menu_list` WHERE fid=0 and priv like"109_all_%"';
        $data = [];
        $data = $this->Fun_model->getSqlData($param);
        foreach ($mod as $val){
	        foreach ($data as $k => $v){
	        	$param['type'] = '';
	        	$param['sql'] = 'SELECT max(`id`)+1 id FROM `menu_list`';
	        	$ids = $this->Fun_model->getSqlData($param);
	        	
	        	$did[$val][$v['id']]=$ids['id'];
	        	$param['sql'] = "INSERT INTO `menu_list` (`name`, `show`, `date`, `url`, `class`, `priv`, `cfg`, `fid`, `asc`, `st`, `et`, `level_type`, `is_display_real`, `is_display_ff`, `time_type`, `is_display_game`, `is_show`, `dropdownInfo`, `installTimeInfo`, `timestamp`, `type`, `userid`, `creatime`, `static`, `textInfo`, `primary_cfg`) 
	        	VALUES ('".$v['name']."','".$v['show']."','".$v['date']."','".$v['url']."','".$ids['id']."','".str_replace("_all_","_".$val."_",$v['priv'])."','".$v['cfg']."','".$v['fid']."','".$v['asc']."','".$v['st']."','".$v['et']."','".$v['level_type']."','".$v['is_display_real']."','".$v['is_display_ff']."','".$v['time_type']."','".$v['is_display_game']."','".$v['is_show']."','".$v['dropdownInfo']."','".$v['installTimeInfo']."','".$v['timestamp']."','".$v['type']."','".$v['userid']."','".$v['creatime']."','".$v['static']."','".$v['textInfo']."','".$v['primary_cfg']."')";
	        	$this->Fun_model->setSqlData($param);
	        	
	        	//var_dump($val,$v,$param);
	        }
        }
        
       foreach ($mod as $val){
	        foreach ($did[$val] as $k => $v){
	        	$param['sql'] = "INSERT INTO `menu_list` (`name`, `show`, `date`, `url`, `class`, `priv`, `cfg`, `fid`, `asc`, `st`, `et`, `level_type`, `is_display_real`, `is_display_ff`, `time_type`, `is_display_game`, `is_show`, `dropdownInfo`, `installTimeInfo`, `timestamp`, `type`, `userid`, `creatime`, `static`, `textInfo`, `primary_cfg`) SELECT `name`, `show`, `date`, `url`, (SELECT LAST_INSERT_ID()+1), REPLACE(`priv`,'_all_','_".$val."_'), `cfg`,'".$v."', `asc`, `st`, `et`, `level_type`, `is_display_real`, `is_display_ff`, `time_type`, `is_display_game`, `is_show`, `dropdownInfo`, `installTimeInfo`, `timestamp`, `type`, `userid`, `creatime`, `static`, `textInfo`, `primary_cfg` FROM `menu_list` WHERE priv like'109_all%' and fid=".$k;
		        $this->Fun_model->setSqlData($param);
		        //var_dump($param);
	        }
        }
        
        foreach ($mod as $val){
	        foreach ($did[$val] as $k => $v){
	        	$param['sql'] = "UPDATE `menu_list` SET `class`=`id` WHERE `fid` =".$v;
	        	$this->Fun_model->setSqlData($param);
	        }
        }
        //var_dump($did);
		
	}
	
	//获取更新两表数据sql
	public function uptables($a='table1',$b='table2',$c=['on'=[],'set'=[],'whe'=[]]){
				
		$sql = "
			UPDATE 
			{$a} 
				inner join {$b} 
			ON 
				r.player_id = a.player_id 
			SET 
				r.channel = a.channel 
			WHERE 
				r.time BETWEEN $from AND $to 
				AND a.time BETWEEN $from AND $to 
				AND r.channel != a.channel
			";
				
		return $sql;		
	}
	
	
	//队列
	class Queue{

		public $redis;
		public $id="test";
		public function __construct(){
			$this->redis = new redis();
			$this->redis->connect('127.0.0.1', 6379);
			//$this->redis->delete($this->id);//清空
		}

		/**
		 * 写入队列(尾部)
		 */
		public function setQueue($cent){
			return $this->redis->rpush($this->id,$cent);
		}

		/**
		 * 获取队列(头部)
		 */
		public function getQueue(){
			while($this->redis->lsize($this->id)){
				$cent = $this->redis->lpop($this->id);
				if($cent){
					var_dump($cent);//do something here/
				}else{
					continue;
					//break;
				}
				sleep(1);
			}
		}
		
	}
	
	
/**
 * 修改xml内容
 * 根据已有xml文件修改后生成新xml
 * @param string $getname
 * @param string $setname
 * @param array $Repdata
 * @param string $xml
 * @return bool|int|string
 */
function setXml($getname = "LuckyW.xml", $setname = "LuckyWtest.xml", $Repdata = ['RATE' => [['old' => '360', 'new' => '526589as'], ['old' => '400', 'new' => '89as'], ['old' => '2500', 'new' => '25']]], $xml = '')
{

    if (!is_file($getname)) {
        return "文件不存在！";
    }

    $simple = file_get_contents($getname);//读取文件
    $p = xml_parser_create();//实例化xml函数
    xml_parse_into_struct($p, $simple, $data, $index);//读取xml
    xml_parser_free($p);//关闭xml实例

    if (count($data)) {

        foreach ($data as $k => $v) {

            //标准xml标签解析后都有type
            if (isset($v['type'])) {

                //双标签必有开始和结束（open 是开始，close 是结束）
                if ($v['type'] == 'open') {

                    //由此参数说明标签行有内容
                    if (isset($v['attributes'])) {

                        $pars = "";
                        foreach ($v['attributes'] as $ks => $vl) {

                            $vl = (count($Repdata) && isset($Repdata[$ks])) ? sirpt($Repdata[$ks], $vl) : $vl;
                            $pars .= $ks . '="' . $vl . '" ';
                        }

                        $xml .= "<{$v['tag']} {$pars}>";

                    } else {
                        $xml .= "<{$v['tag']}>";
                    }
                }//内容标签或单标签
                elseif ($v['type'] == 'complete') {

                    //次参数代表有内容的双标签
                    if (isset($v['value'])) {

                        if (isset($v['attributes'])) {

                            $pars = "";
                            foreach ($v['attributes'] as $ks => $vl) {

                                $vl = (count($Repdata) && isset($Repdata[$ks])) ? sirpt($Repdata[$ks], $vl) : $vl;
                                $pars .= $ks . '="' . $vl . '" ';
                            }

                            $xml .= "<{$v['tag']} {$pars}>{$v['value']}</{$v['tag']}>";

                        } else {
                            $xml .= "<{$v['tag']}>{$v['value']}</{$v['tag']}>";
                        }
                    } else {
                        if (isset($v['attributes'])) {

                            $pars = "";
                            foreach ($v['attributes'] as $ks => $vl) {

                                $vl = (count($Repdata) && isset($Repdata[$ks])) ? sirpt($Repdata[$ks], $vl) : $vl;
                                $pars .= $ks . '="' . $vl . '" ';
                            }

                            $xml .= "<{$v['tag']} {$pars}/>";

                        } else {
                            $xml .= "<{$v['tag']}/>";
                        }
                    }

                }//双标签结尾标签
                elseif ($v['type'] == 'close') {
                    $xml .= "</{$v['tag']}>";
                } else {

                }

            } else {

            }
        }

        return file_put_contents($setname, $xml);
    } else {
        return "数据为空！";
    }
}

/**
 * 替换（不递归）
 * @param $d
 * @param $v
 * @return mixed
 */
function sirpt($d, $v)
{

    if (count($d) && is_array($d) && !empty($v)) {

        if (isset($d['old']) && isset($d['new'])) {

            $v = str_ireplace($d['old'], $d['new'], $v);
        } else {

            foreach ($d as $vl) {

                if (isset($vl['old']) && isset($vl['new'])) {
                    $v = str_ireplace($vl['old'], $vl['new'], $v);
                }
            }
        }

    }
    return $v;

}

setXml();


?>
--SQL--

--插入表
INSERT INTO `menu_list` (`name`, `show`) SELECT `name`, `show` FROM `menu_list` WHERE fid=0

SHOW DATABASES; --查询当前服务器的所有库；
SHOW TABLES FROM 库名; --查询当前库里所有表；
SHOW FULL COLUMNS FROM  库名.表名"; --查询表里所有字段及详情；

--改变自增值
alter table menu_list AUTO_INCREMENT=441; 

--查询自增
select max(id) from tablename;
SELECT LAST_INSERT_ID();
select @@IDENTITY;

--表详情
SHOW TABLE STATUS;

CONCAT() 拼接字符串
FORMAT() 保留几位小数
-----

-----存储过程式插入多条递增数据-------

-- 清空数据表
truncate table third_party_server;

-- 删除存储表
drop procedure myproc;

-- 程序开始
delimiter //
-- 创建存储过程表
create procedure myproc() 
begin 
-- 定义变量
declare num int; 
declare num1 int; 
-- 变量赋值
set num=0; 
set num1=10001;
-- 循环开始
while num < 20050 do 
insert into third_party_server(area_id, server_code) values(num, num1); 
set num=num+1;
set num1=num1+1;
-- 循环结束
end while;
end//

-- 执行存储过程
delimiter ;
call myproc();

-- 删除多余数据
DELETE FROM third_party_server WHERE area_id >9999 AND area_id<20000

-- 当插入数据主键存在是更新当前数据
insert into third_party_server(area_id, server_code) values(num, num1) ON DUPLICATE KEY UPDATE num = values(num), num1 = values(num1),ideid=if(ideid=0 or ideid='',VALUES(ideid),ideid)

-- 合并多表查询结果（每张表结构要一样，适用于分表）	
UNION用的比较多union all是直接连接，取到得是所有值，记录可能有重复   union 是取唯一值

-- 查看所有数据库占用磁盘大小
select 
TABLE_SCHEMA, 
concat(truncate(sum(data_length)/1024/1024,2),' MB') as data_size,
concat(truncate(sum(index_length)/1024/1024,2),'MB') as index_size
from information_schema.tables
group by TABLE_SCHEMA
ORDER BY data_size desc;


网上搜索得知内联表查询一般的执行过程是：
1、执行FROM语句
2、执行ON过滤
3、添加外部行
4、执行where条件过滤
5、执行group by分组语句
6、执行having
7、select列表
8、执行distinct去重复数据
9、执行order by字句
10、执行limit字句

-- 自动备份表开始
DROP PROCEDURE if EXISTS move_log;
CREATE PROCEDURE move_log()
BEGIN 
  #创建日志表
 SET @temp_command = CONCAT("ALTER TABLE log_content RENAME TO log_content_",DATE_FORMAT(DATE_SUB(curdate(),INTERVAL 1 DAY),"%Y%m%d"));
 PREPARE command_table_sql FROM @temp_command;
 EXECUTE command_table_sql;
 
 CREATE TABLE `log_content` (
   `L_type` char(255) NOT NULL COMMENT '标签（同log_type_config表一致）',
   `L_ename` char(255) NOT NULL COMMENT '开关名称',
   `L_fds` int(11) NOT NULL COMMENT '时间戳（服务器的）',
   `L_cpfds` varchar(25) NOT NULL COMMENT '客户端时间',
   `L_uid` varchar(255) DEFAULT NULL COMMENT '用户id',
   `L_gameid` varchar(255) DEFAULT NULL COMMENT '游戏id',
   `L_channelid` varchar(255) DEFAULT NULL COMMENT '渠道id',
   `L_logname` char(255) NOT NULL COMMENT '日志名称（标签、步骤、说明等便于定位）',
   `L_logcontent` mediumtext COMMENT '日志内容（json格式）',
   `L_extradata` mediumtext COMMENT '附加数据',
   `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
   KEY `L_type` (`L_type`),
   KEY `L_ename` (`L_ename`),
   KEY `L_fds` (`L_fds`),
   KEY `L_uid` (`L_uid`),
   KEY `L_gameid` (`L_gameid`),
   KEY `L_channelid` (`L_channelid`),
   KEY `L_logname` (`L_logname`),
   KEY `create_time` (`create_time`),
   KEY `L_cpfds` (`L_cpfds`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
 
END;

--一天跑一次，每天凌晨0:05分跑
DROP EVENT  if exists move_log_event ;
CREATE EVENT move_log_event 
  ON SCHEDULE EVERY 1 DAY STARTS '2019-03-13 0:0:5'  
do call move_log();

-- 自动备份表结束


/******JQ/JS部分******/
<script>

//select默认值改变时，重新加载选中值
//$(".chosen-select").trigger("liszt:updated");

/**
 * 异步获取 ajax 
 * type：POST/GET 
 * url：提交地址
 * fun：处理函数名(Ajaxs_Hq.Ax_Opt=function)
 * das：提交数据
 * tal：传参处理函数
 * 注：异步返回值需json
 * Ajaxs_JQ("POST",url,das,"Ax_Opt",e);
 * Ajaxs_JS("GET",url,"Ax_Opt",e);
 */
function Ajaxs_JS(type, url, fun, tal) {
　　　　var xhr = new XMLHttpRequest();
		xhr.open(type, url);
		xhr.onload = function () {
			if(xhr.response){		
				fun = fun? fun:"Ax_Opt";
				Ajaxs_Hq[fun](JSON.parse(xhr.response), tal);	
			}else{
				alert("抱歉：暂无相关数据！");
				return false;
			}
　　　　};
　　　　xhr.send(null);
}

function Ajaxs_JQ(tys, urs, das, fun, tal) {
	$.ajax({
	    url : urs,
	    type : tys,
	    data : das,
	    dataType : 'json',
	    success : function(data) {
	    	if(data){
				Ajaxs_Hq[fun](data, tal, das);	
			}else{
				alert("抱歉：暂无相关数据！");
				return false;
			}
	    }
	});
}


/**
 * ajax回调方法 数据处理
 */
var Ajaxs_Hq = {};
Ajaxs_Hq.Ax_Opt=function(arr, tal, das){}


/**
         * 闭包写法
         * ;(function () {})();
         */
;(function () {})();


/**
 * 注册获取get参数函数
 * var notfill = $.getUrlParam('notfill');
 */
(function ($) {
    $.getUrlParam = function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]); return null;
    }
})(jQuery);


// Array Remove - By John Resig (MIT Licensed)
/**
 * 删除数组指定元素，下标自动重建
 * @param from
 * @param to
 * @returns {Number}
 */
Array.prototype.remove = function (from, to) {
    var rest = this.slice((to || from) + 1 || this.length);
    this.length = from < 0 ? this.length + from : from;
    return this.push.apply(this, rest);
};

</script>





shell脚本：

【统计连接情况开始】
netstat -tunp | awk '
BEGIN{
    chromeNum = 0;
}
{
    if(NR>2){
        split($4,myInfo,":");
        split($5,taInfo,":");
        split($7,appInfo,"/");
        myIP = myInfo[1];
        myPort = myInfo[2];
        taIp = taInfo[1];
        taPort = taInfo[2];
        pid = appInfo[1];
        appName = appInfo[2];
        chromeNum++;
        state[$6]++;
        connCountTa[myIP"->"taIp":"taPort"="$6]++;
        connCountMe[myIP":"myPort"->"taIp"="$6]++;
        connCountAll[myIP"->"taIp"="$6]++;
    }
}
END{
    print "总数："chromeNum;
    print "根据发出请求ip及状态统计：">> "connCountTa.log"
    for(key in connCountTa){
        print key,connCountTa[key] >> "connCountTa.log";
    }
    print "根据接收请求ip及状态统计：">> "connCountMe.log"
    for(key in connCountMe){
        print key,connCountMe[key] >> "connCountMe.log";
    }
    print "根据ip及状态统计：">> "connCountAll.log"
    for(key in connCountAll){
        print key,connCountAll[key] >> "connCountAll.log";
    }
}'
iptables -I INPUT -p tcp --dport 443 -s XXX.XXX.XXX.XXX  -j ACCEPT
iptables -I INPUT -p tcp --dport 443 -s XXX.XXX.XXX.XXX  -m connlimit --connlimit-above 100 -j REJECT

【部分参数说明】

【-s】IP地址可以不要，则默认匹配全部
【–dport】设置匹配端口
【-j】设置操作，一般是两个REJECT（拒绝）、ACCEPT（允许）
【第一个参数】-I 添加， -D删除
【统计连接情况结束】



###过滤同时连接IP上线
iptables -I INPUT -p tcp --dport 443   -m connlimit --connlimit-above 10 -j REJECT
iptables -I INPUT -p tcp --dport 80   -m connlimit --connlimit-above 10 -j REJECT

